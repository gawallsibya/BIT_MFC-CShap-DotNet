// DB2Set.h : interface of the CDB2Set class
//
/////////////////////////////////////////////////////////////////////////////

#if !defined(AFX_DB2SET_H__AA236E7F_E504_4F93_911D_BEDF7B5A7791__INCLUDED_)
#define AFX_DB2SET_H__AA236E7F_E504_4F93_911D_BEDF7B5A7791__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class CDB2Set : public CRecordset
{
public:
	CDB2Set(CDatabase* pDatabase = NULL);
	DECLARE_DYNAMIC(CDB2Set)

// Field/Param Data
	//{{AFX_FIELD(CDB2Set, CRecordset)
	long	m_CUSTOM_CD;
	CString	m_NAME;
	CString	m_TEL;
	CString	m_ADDRESS;
	//}}AFX_FIELD

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CDB2Set)
	public:
	virtual CString GetDefaultConnect();	// Default connection string
	virtual CString GetDefaultSQL(); 	// default SQL for Recordset
	virtual void DoFieldExchange(CFieldExchange* pFX);	// RFX support
	//}}AFX_VIRTUAL

// Implementation
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_DB2SET_H__AA236E7F_E504_4F93_911D_BEDF7B5A7791__INCLUDED_)

