// DB2View.cpp : implementation of the CDB2View class
//

#include "stdafx.h"
#include "DB2.h"

#include "DB2Set.h"
#include "DB2Doc.h"
#include "DB2View.h"


#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CDB2View

IMPLEMENT_DYNCREATE(CDB2View, CRecordView)

BEGIN_MESSAGE_MAP(CDB2View, CRecordView)
	//{{AFX_MSG_MAP(CDB2View)
	ON_BN_CLICKED(IDC_BUTTON_BTN, OnButtonBtn)
	ON_BN_CLICKED(IDC_BUTTON_SEARCH, OnButtonSearch)
	ON_BN_CLICKED(IDC_BUTTON_DELETE, OnButtonDelete)
	ON_BN_CLICKED(IDC_BUTTON_MODIFY, OnButtonModify)
	//}}AFX_MSG_MAP
	// Standard printing commands
	ON_COMMAND(ID_FILE_PRINT, CRecordView::OnFilePrint)
	ON_COMMAND(ID_FILE_PRINT_DIRECT, CRecordView::OnFilePrint)
	ON_COMMAND(ID_FILE_PRINT_PREVIEW, CRecordView::OnFilePrintPreview)
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CDB2View construction/destruction

CDB2View::CDB2View()
	: CRecordView(CDB2View::IDD)
{
	//{{AFX_DATA_INIT(CDB2View)
	m_pSet = NULL;
	//}}AFX_DATA_INIT
	// TODO: add construction code here

}

CDB2View::~CDB2View()
{
}

void CDB2View::DoDataExchange(CDataExchange* pDX)
{
	CRecordView::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CDB2View)
	DDX_FieldText(pDX, IDC_EDIT_ADDRESS, m_pSet->m_CUSTOM_CD, m_pSet);
	DDX_FieldText(pDX, IDC_EDIT_NAME, m_pSet->m_NAME, m_pSet);
	DDX_FieldText(pDX, IDC_EDIT_PHONE, m_pSet->m_TEL, m_pSet);
	//}}AFX_DATA_MAP
}

BOOL CDB2View::PreCreateWindow(CREATESTRUCT& cs)
{
	// TODO: Modify the Window class or styles here by modifying
	//  the CREATESTRUCT cs

	return CRecordView::PreCreateWindow(cs);
}

void CDB2View::OnInitialUpdate()
{



	m_pSet = &GetDocument()->m_dB2Set;
	if(m_pSet->IsOpen())
		m_pSet->Close();

	m_pSet->Open();
	CRecordView::OnInitialUpdate();

}

/////////////////////////////////////////////////////////////////////////////
// CDB2View printing

BOOL CDB2View::OnPreparePrinting(CPrintInfo* pInfo)
{
	// default preparation
	return DoPreparePrinting(pInfo);
}

void CDB2View::OnBeginPrinting(CDC* /*pDC*/, CPrintInfo* /*pInfo*/)
{
	// TODO: add extra initialization before printing
}

void CDB2View::OnEndPrinting(CDC* /*pDC*/, CPrintInfo* /*pInfo*/)
{
	// TODO: add cleanup after printing
}

/////////////////////////////////////////////////////////////////////////////
// CDB2View diagnostics

#ifdef _DEBUG
void CDB2View::AssertValid() const
{
	CRecordView::AssertValid();
}

void CDB2View::Dump(CDumpContext& dc) const
{
	CRecordView::Dump(dc);
}

CDB2Doc* CDB2View::GetDocument() // non-debug version is inline
{
	ASSERT(m_pDocument->IsKindOf(RUNTIME_CLASS(CDB2Doc)));
	return (CDB2Doc*)m_pDocument;
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CDB2View database support
CRecordset* CDB2View::OnGetRecordset()
{
	return m_pSet;
}


/////////////////////////////////////////////////////////////////////////////
// CDB2View message handlers

BOOL CDB2View::OnMove(UINT nIDMoveCommand)
{
	switch (nIDMoveCommand)
	{
	case ID_RECORD_PREV:
		if(m_pSet->IsBOF())
			break;
		m_pSet->MovePrev();
		break;
	case ID_RECORD_FIRST:
		m_pSet->MoveFirst();
		break;
	case ID_RECORD_NEXT:
		if(m_pSet->IsEOF())
			break;
		m_pSet->MoveNext();
		break;
	case ID_RECORD_LAST:
		m_pSet->MoveLast();
		break;
	default:
		ASSERT(FALSE);
		break;
	}
	UpdateData(FALSE);

	return TRUE;
}

BOOL CDB2View::DestroyWindow() 
{
	// TODO: Add your specialized code here and/or call the base class
	
	return CRecordView::DestroyWindow();
}

void CDB2View::OnButtonBtn() 
{
	// TODO: Add your control notification handler code here
	if(!m_flagAdd)
		return;

	// ������ ���ڵ�� �̵�
	m_pSet->MoveLast();
	int i = m_pSet->m_CUSTOM_CD+1;
	
	// ���ڵ带 �߰��Ѵ�.
	m_pSet->AddNew();
/*
//===========================
	CString buf;
	GetDlgItemText(IDC_EDIT_NAME,buf);

	m_pSet->m_CUSTOM_CD		= i;
	m_pSet->m_NAME			= buf;
	GetDlgItemText(IDC_EDIT_ADDRESS,buf);
	m_pSet->m_ADDRESS		= buf;
	GetDlgItemText(IDC_EDIT_PHONE,buf);
	m_pSet->m_TEL			= buf;



//============================
*/


	// ���ڵ忡 ���ҽ� ����(��Ʈ�ѿ� �Էµ� ��)�� ���� 
	ResourceToDB(i);

	// ����Ʈ ��Ʈ�� ���� 
//	UpdateList();
	//m_pSet->m_CUSTOM_CD = m_pSet->m_CUSTOM_CD+1;
//	m_flagAdd = FALSE;
//	m_flagFirst = FALSE;
//	m_FlagLast = TRUE;

	// �߰��� ���ڵ带 �����ͺ��̽��� ���� 
	m_pSet->Update();

}




void CDB2View::ResourceToDB(int i)
{
	CString buf;
	GetDlgItemText(IDC_EDIT_NAME,buf);

	m_pSet->m_CUSTOM_CD		= i;
	m_pSet->m_NAME			= buf;
	GetDlgItemText(IDC_EDIT_ADDRESS,buf);
	m_pSet->m_ADDRESS		= buf;
	GetDlgItemText(IDC_EDIT_PHONE,buf);
	m_pSet->m_TEL			= buf;

}


void CDB2View::OnButtonSearch() 
{
	// TODO: Add your control notification handler code here
		// TODO: Add your control notification handler code here
	CString buf;
	GetDlgItemText(IDC_EDIT_NAMESEARCH,buf);
	
	
	m_pSet->m_strFilter.Format("NAME= '%s'", buf);
	m_pSet->Requery();	


	UpdateData(FALSE);
}

void CDB2View::OnButtonDelete() 
{
	// TODO: Add your control notification handler code here
		//���� ���ڵ带 �����Ѵ�.
	m_pSet->Delete();

	//�������ڵ�� �̵��Ѵ�.
	m_pSet->MoveNext();
	//���ڵ尡 �������̸�

	if(m_pSet->IsEOF())
		m_pSet->MoveLast(); //���������� �̵���Ų��.
	//���ڵ尡 ó���̸�
	if(m_pSet->IsBOF())
		m_pSet->SetFieldNull(NULL); //�η� ä���
	
	//���� Ŀ���� DB�ڷḦ ���ҽ��� �ű��.
	//ȭ���� �ٽ� �����Ѵ�.
	UpdateData(FALSE);
}

void CDB2View::OnButtonModify() 
{
	// TODO: Add your control notification handler code here
		// TODO: Add your control notification handler code here

	CString buf;
	GetDlgItemText(IDC_EDIT_NAME,buf);

	m_pSet->Edit();
	m_pSet->m_NAME = buf;
	GetDlgItemText(IDC_EDIT_ADDRESS,buf);
	m_pSet->m_ADDRESS		= buf;
	GetDlgItemText(IDC_EDIT_PHONE,buf);
	m_pSet->m_TEL			= buf;

	
	// �߰��� ���ڵ带 �����ͺ��̽��� ���� 
	m_pSet->Update();

	UpdateData(FALSE);
}
