// DB2Doc.h : interface of the CDB2Doc class
//
/////////////////////////////////////////////////////////////////////////////

#if !defined(AFX_DB2DOC_H__1DCDF7E2_5A34_4EE3_A62E_243CB69D221B__INCLUDED_)
#define AFX_DB2DOC_H__1DCDF7E2_5A34_4EE3_A62E_243CB69D221B__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
#include "DB2Set.h"


class CDB2Doc : public CDocument
{
protected: // create from serialization only
	CDB2Doc();
	DECLARE_DYNCREATE(CDB2Doc)

// Attributes
public:
	CDB2Set m_dB2Set;

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CDB2Doc)
	public:
	virtual BOOL OnNewDocument();
	//}}AFX_VIRTUAL

// Implementation
public:
	virtual ~CDB2Doc();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:

// Generated message map functions
protected:
	//{{AFX_MSG(CDB2Doc)
		// NOTE - the ClassWizard will add and remove member functions here.
		//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_DB2DOC_H__1DCDF7E2_5A34_4EE3_A62E_243CB69D221B__INCLUDED_)
