// DB2Doc.cpp : implementation of the CDB2Doc class
//

#include "stdafx.h"
#include "DB2.h"

#include "DB2Set.h"
#include "DB2Doc.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CDB2Doc

IMPLEMENT_DYNCREATE(CDB2Doc, CDocument)

BEGIN_MESSAGE_MAP(CDB2Doc, CDocument)
	//{{AFX_MSG_MAP(CDB2Doc)
		// NOTE - the ClassWizard will add and remove mapping macros here.
		//    DO NOT EDIT what you see in these blocks of generated code!
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CDB2Doc construction/destruction

CDB2Doc::CDB2Doc()
{
	// TODO: add one-time construction code here

}

CDB2Doc::~CDB2Doc()
{
}

BOOL CDB2Doc::OnNewDocument()
{
	if (!CDocument::OnNewDocument())
		return FALSE;

	// TODO: add reinitialization code here
	// (SDI documents will reuse this document)

	return TRUE;
}



/////////////////////////////////////////////////////////////////////////////
// CDB2Doc diagnostics

#ifdef _DEBUG
void CDB2Doc::AssertValid() const
{
	CDocument::AssertValid();
}

void CDB2Doc::Dump(CDumpContext& dc) const
{
	CDocument::Dump(dc);
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CDB2Doc commands
