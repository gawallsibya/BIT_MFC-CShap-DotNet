// DB2View.h : interface of the CDB2View class
//
/////////////////////////////////////////////////////////////////////////////

#if !defined(AFX_DB2VIEW_H__1897571E_46C4_4DD3_895C_088343E340E1__INCLUDED_)
#define AFX_DB2VIEW_H__1897571E_46C4_4DD3_895C_088343E340E1__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class CDB2Set;

class CDB2View : public CRecordView
{
protected: // create from serialization only
	CDB2View();
	DECLARE_DYNCREATE(CDB2View)

public:
	//{{AFX_DATA(CDB2View)
	enum { IDD = IDD_DB2_FORM };
	CDB2Set* m_pSet;
	//}}AFX_DATA

// Attributes
public:
	CDB2Doc* GetDocument();
	BOOL m_flagAdd;
	BOOL m_flagFirst;
	BOOL m_FlagLast;



	CListCtrl	m_listTape;

//	CString	m_strAddress;
	CString	m_strName;
	CString	m_strTel;
	long	m_lCode;
// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CDB2View)
	public:
	virtual CRecordset* OnGetRecordset();
	virtual BOOL PreCreateWindow(CREATESTRUCT& cs);
	virtual BOOL DestroyWindow();
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	virtual void OnInitialUpdate(); // called first time after construct
	virtual BOOL OnPreparePrinting(CPrintInfo* pInfo);
	virtual void OnBeginPrinting(CDC* pDC, CPrintInfo* pInfo);
	virtual void OnEndPrinting(CDC* pDC, CPrintInfo* pInfo);
	//}}AFX_VIRTUAL

// Implementation
public:
	void ResourceToDB(int i);
	BOOL OnMove(UINT nIDMoveCommand);
	virtual ~CDB2View();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:

// Generated message map functions
protected:
	//{{AFX_MSG(CDB2View)
	afx_msg void OnButtonBtn();
	afx_msg void OnButtonSearch();
	afx_msg void OnButtonDelete();
	afx_msg void OnButtonModify();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

#ifndef _DEBUG  // debug version in DB2View.cpp
inline CDB2Doc* CDB2View::GetDocument()
   { return (CDB2Doc*)m_pDocument; }
#endif

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_DB2VIEW_H__1897571E_46C4_4DD3_895C_088343E340E1__INCLUDED_)
