// DB2Set.cpp : implementation of the CDB2Set class
//

#include "stdafx.h"
#include "DB2.h"
#include "DB2Set.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CDB2Set implementation

IMPLEMENT_DYNAMIC(CDB2Set, CRecordset)

CDB2Set::CDB2Set(CDatabase* pdb)
	: CRecordset(pdb)
{
	//{{AFX_FIELD_INIT(CDB2Set)
	m_CUSTOM_CD = 0;
	m_NAME = _T("");
	m_TEL = _T("");
	m_ADDRESS = _T("");
	m_nFields = 4;
	//}}AFX_FIELD_INIT
	m_nDefaultType = dynaset;
}

CString CDB2Set::GetDefaultConnect()
{
	return _T("ODBC;DSN=Video Shop Administration");
}

CString CDB2Set::GetDefaultSQL()
{
	return _T("[Customer]");
}

void CDB2Set::DoFieldExchange(CFieldExchange* pFX)
{
	//{{AFX_FIELD_MAP(CDB2Set)
	pFX->SetFieldType(CFieldExchange::outputColumn);
	RFX_Long(pFX, _T("[CUSTOM_CD]"), m_CUSTOM_CD);
	RFX_Text(pFX, _T("[NAME]"), m_NAME);
	RFX_Text(pFX, _T("[TEL]"), m_TEL);
	RFX_Text(pFX, _T("[ADDRESS]"), m_ADDRESS);
	//}}AFX_FIELD_MAP
}

/////////////////////////////////////////////////////////////////////////////
// CDB2Set diagnostics

#ifdef _DEBUG
void CDB2Set::AssertValid() const
{
	CRecordset::AssertValid();
}

void CDB2Set::Dump(CDumpContext& dc) const
{
	CRecordset::Dump(dc);
}
#endif //_DEBUG
