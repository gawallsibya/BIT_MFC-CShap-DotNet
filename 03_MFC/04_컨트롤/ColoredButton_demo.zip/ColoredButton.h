// ColoredButton.h : main header file for the COLOREDBUTTON application
//

#if !defined(AFX_COLOREDBUTTON_H__80B777D4_C624_44FD_B42C_8A2FF2749E25__INCLUDED_)
#define AFX_COLOREDBUTTON_H__80B777D4_C624_44FD_B42C_8A2FF2749E25__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#ifndef __AFXWIN_H__
	#error include 'stdafx.h' before including this file for PCH
#endif

#include "resource.h"		// main symbols

/////////////////////////////////////////////////////////////////////////////
// CColoredButtonApp:
// See ColoredButton.cpp for the implementation of this class
//

class CColoredButtonApp : public CWinApp
{
public:
	CColoredButtonApp();

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CColoredButtonApp)
	public:
	virtual BOOL InitInstance();
	//}}AFX_VIRTUAL

// Implementation

	//{{AFX_MSG(CColoredButtonApp)
		// NOTE - the ClassWizard will add and remove member functions here.
		//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};


/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_COLOREDBUTTON_H__80B777D4_C624_44FD_B42C_8A2FF2749E25__INCLUDED_)
