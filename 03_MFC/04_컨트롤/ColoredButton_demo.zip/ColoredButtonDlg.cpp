// ColoredButtonDlg.cpp : implementation file
//

#include "stdafx.h"
#include "ColoredButton.h"
#include "ColoredButtonDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

const COLORREF CLOUDBLUE = RGB(128, 184, 223);
const COLORREF WHITE = RGB(255, 255, 255);
const COLORREF BLACK = RGB(1, 1, 1);
const COLORREF DKGRAY = RGB(128, 128, 128);
const COLORREF LLTGRAY = RGB(220, 220, 220);
const COLORREF LTGRAY = RGB(192, 192, 192);
const COLORREF YELLOW = RGB(255, 255, 0);
const COLORREF DKYELLOW = RGB(128, 128, 0);
const COLORREF RED = RGB(255, 0, 0);
const COLORREF DKRED = RGB(128, 0, 0);
const COLORREF BLUE = RGB(0, 0, 255);
const COLORREF LBLUE = RGB(192, 192, 255);
const COLORREF DKBLUE = RGB(0, 0, 128);
const COLORREF CYAN = RGB(0, 255, 255);
const COLORREF DKCYAN = RGB(0, 128, 128);
const COLORREF GREEN = RGB(0, 255, 0);
const COLORREF DKGREEN = RGB(0, 128, 0);
const COLORREF MAGENTA = RGB(255, 0, 255);
const COLORREF DKMAGENTA = RGB(128, 0, 128);

/////////////////////////////////////////////////////////////////////////////
// CAboutDlg dialog used for App About

class CAboutDlg : public CDialog
{
public:
	CAboutDlg();

// Dialog Data
	//{{AFX_DATA(CAboutDlg)
	enum { IDD = IDD_ABOUTBOX };
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CAboutDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	//{{AFX_MSG(CAboutDlg)
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

CAboutDlg::CAboutDlg() : CDialog(CAboutDlg::IDD)
{
	//{{AFX_DATA_INIT(CAboutDlg)
	//}}AFX_DATA_INIT
}

void CAboutDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CAboutDlg)
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CAboutDlg, CDialog)
	//{{AFX_MSG_MAP(CAboutDlg)
		// No message handlers
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CColoredButtonDlg dialog

CColoredButtonDlg::CColoredButtonDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CColoredButtonDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CColoredButtonDlg)
	//}}AFX_DATA_INIT
	// Note that LoadIcon does not require a subsequent DestroyIcon in Win32
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
}

void CColoredButtonDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CColoredButtonDlg)
	DDX_Control(pDX, IDC_BUTTON6, m_button6);
	DDX_Control(pDX, IDC_BUTTON5, m_button5);
	DDX_Control(pDX, IDC_BUTTON4, m_button4);
	DDX_Control(pDX, IDC_BUTTON3, m_button3);
	DDX_Control(pDX, IDC_BUTTON2, m_button2);
	DDX_Control(pDX, IDC_BUTTON1, m_button1);
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CColoredButtonDlg, CDialog)
	//{{AFX_MSG_MAP(CColoredButtonDlg)
	ON_WM_SYSCOMMAND()
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	ON_BN_CLICKED(IDC_BUTTON1, OnButton1)
	ON_BN_CLICKED(IDC_BUTTON4, OnButton4)
	ON_BN_CLICKED(IDC_BUTTON6, OnButton6)
	ON_BN_CLICKED(IDC_BUTTON3, OnButton3)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CColoredButtonDlg message handlers

BOOL CColoredButtonDlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	// Add "About..." menu item to system menu.

	// IDM_ABOUTBOX must be in the system command range.
	ASSERT((IDM_ABOUTBOX & 0xFFF0) == IDM_ABOUTBOX);
	ASSERT(IDM_ABOUTBOX < 0xF000);

	CMenu* pSysMenu = GetSystemMenu(FALSE);
	if (pSysMenu != NULL)
	{
		CString strAboutMenu;
		strAboutMenu.LoadString(IDS_ABOUTBOX);
		if (!strAboutMenu.IsEmpty())
		{
			pSysMenu->AppendMenu(MF_SEPARATOR);
			pSysMenu->AppendMenu(MF_STRING, IDM_ABOUTBOX, strAboutMenu);
		}
	}

	// Set the icon for this dialog.  The framework does this automatically
	//  when the application's main window is not a dialog
	SetIcon(m_hIcon, TRUE);			// Set big icon
	SetIcon(m_hIcon, FALSE);		// Set small icon

	fontVerdana = new CFont;
	fontVerdana->CreateFont(
		12,                        // nHeight
		0,                         // nWidth
		0,                         // nEscapement
		0,                         // nOrientation
		FW_NORMAL,                 // nWeight
		FALSE,						// bItalic
		FALSE,                     // bUnderline
		0,                         // cStrikeOut
		ANSI_CHARSET,              // nCharSet
		OUT_DEFAULT_PRECIS,        // nOutPrecision
		CLIP_DEFAULT_PRECIS,       // nClipPrecision
		DEFAULT_QUALITY,           // nQuality
		DEFAULT_PITCH | FF_SWISS,  // nPitchAndFamily
		"Verdana");        // lpszFacename	

	fontGeorgia = new CFont;
	fontGeorgia->CreateFont(
		15,                        // nHeight
		0,                         // nWidth
		0,                         // nEscapement
		0,                         // nOrientation
		FW_NORMAL,                 // nWeight
		FALSE,						// bItalic
		FALSE,                     // bUnderline
		0,                         // cStrikeOut
		ANSI_CHARSET,              // nCharSet
		OUT_DEFAULT_PRECIS,        // nOutPrecision
		CLIP_DEFAULT_PRECIS,       // nClipPrecision
		DEFAULT_QUALITY,           // nQuality
		DEFAULT_PITCH | FF_SWISS,  // nPitchAndFamily
		"Georgia");        // lpszFacename

	m_button1.SetColor(RED, WHITE);
	m_button2.SetColor(YELLOW, MAGENTA, WHITE);
	m_button3.SetColor(RED, BLUE, LTGRAY, CYAN, LBLUE, GREEN, DKGREEN);

	m_button4.SetColor(YELLOW, RED);
	m_button5.SetColor(BLACK, GREEN, LLTGRAY);
	m_button6.SetColor(WHITE, BLACK, LTGRAY, WHITE, LBLUE, LTGRAY, DKBLUE);	

	m_button4.SetFont(fontVerdana);
	m_button6.SetFont(fontVerdana);

	CRect rc;
	GetDlgItem(IDC_STATIC_DYN)->GetWindowRect(rc);
	rc.DeflateRect(10,20,20,10);
	rc.top -= 35;
	rc.bottom -= 25;
	
	m_dynamic = new CColorButton;
	m_dynamic->Create("Dynamic\nCreated", 
		WS_CHILD|WS_VISIBLE|BS_PUSHBUTTON|BS_OWNERDRAW|BS_MULTILINE,
		rc,this,IDC_BUTTON_DYN);
	m_dynamic->SetFont(fontGeorgia);
	m_dynamic->SetColor(BLUE, LBLUE);
	m_dynamic->ShowWindow(SW_SHOW);
	
	return TRUE;  // return TRUE  unless you set the focus to a control
}

void CColoredButtonDlg::OnSysCommand(UINT nID, LPARAM lParam)
{
	if ((nID & 0xFFF0) == IDM_ABOUTBOX)
	{
		CAboutDlg dlgAbout;
		dlgAbout.DoModal();
	}
	else
	{
		CDialog::OnSysCommand(nID, lParam);
	}
}

// If you add a minimize button to your dialog, you will need the code below
//  to draw the icon.  For MFC applications using the document/view model,
//  this is automatically done for you by the framework.

void CColoredButtonDlg::OnPaint() 
{
	if (IsIconic())
	{
		CPaintDC dc(this); // device context for painting

		SendMessage(WM_ICONERASEBKGND, (WPARAM) dc.GetSafeHdc(), 0);

		// Center icon in client rectangle
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// Draw the icon
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialog::OnPaint();
	}
}

// The system calls this to obtain the cursor to display while the user drags
//  the minimized window.
HCURSOR CColoredButtonDlg::OnQueryDragIcon()
{
	return (HCURSOR) m_hIcon;
}

BOOL CColoredButtonDlg::DestroyWindow() 
{
	fontVerdana->DeleteObject();
	delete fontVerdana;
	
	fontGeorgia->DeleteObject();
	delete fontGeorgia;

	m_dynamic->DestroyWindow();
	delete m_dynamic;
	m_dynamic = NULL;
	
	return CDialog::DestroyWindow();
}

void CColoredButtonDlg::OnButton1() 
{
	BOOL bEnabled = GetDlgItem(IDC_BUTTON2)->IsWindowEnabled();
	GetDlgItem(IDC_BUTTON2)->EnableWindow(!bEnabled);

	DWORD dwStyles = GetWindowLong(m_dynamic->GetSafeHwnd(), GWL_STYLE);
	dwStyles &= ~BS_MULTILINE;
	SetWindowLong(m_dynamic->GetSafeHwnd(), GWL_STYLE, dwStyles);
	m_dynamic->SetWindowText("Dynamic Created");
	m_dynamic->Invalidate();	
}

void CColoredButtonDlg::OnButton4() 
{
	BOOL bEnabled = GetDlgItem(IDC_BUTTON5)->IsWindowEnabled();
	GetDlgItem(IDC_BUTTON5)->EnableWindow(!bEnabled);
	if(bEnabled)
		GetDlgItem(IDC_BUTTON5)->SetWindowText("Disabled\nMulti\nLine\nButton");
	else
		GetDlgItem(IDC_BUTTON5)->SetWindowText("Enabled\nMulti\nLine\nButton");

	DWORD dwStyles = GetWindowLong(m_dynamic->GetSafeHwnd(), GWL_STYLE);
	dwStyles &= ~BS_RIGHT;
	dwStyles |= BS_LEFT;
	SetWindowLong(m_dynamic->GetSafeHwnd(), GWL_STYLE, dwStyles);
	m_dynamic->Invalidate();
}

void CColoredButtonDlg::OnButton6() 
{
	DWORD dwStyles = GetWindowLong(m_dynamic->GetSafeHwnd(), GWL_STYLE);
	dwStyles &= ~BS_LEFT;
	dwStyles |= BS_RIGHT;
	SetWindowLong(m_dynamic->GetSafeHwnd(), GWL_STYLE, dwStyles);
	m_dynamic->Invalidate();
}

void CColoredButtonDlg::OnButton3() 
{
	DWORD dwStyles = GetWindowLong(m_dynamic->GetSafeHwnd(), GWL_STYLE);
	dwStyles |= BS_MULTILINE;
	SetWindowLong(m_dynamic->GetSafeHwnd(), GWL_STYLE, dwStyles);
	m_dynamic->SetWindowText("Dynamic\nCreated");
	m_dynamic->Invalidate();	
}
